// EmployeeCard component
