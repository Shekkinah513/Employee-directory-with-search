// SearchBar component
